<script lang="ts">
  import AdminShell from '$lib/components/AdminShell.svelte';
</script>

<AdminShell>
  <slot />
</AdminShell>
